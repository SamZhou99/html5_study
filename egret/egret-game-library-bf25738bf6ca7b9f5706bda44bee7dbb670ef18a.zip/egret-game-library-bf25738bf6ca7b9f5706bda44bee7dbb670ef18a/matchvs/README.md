# Matchvs 游戏云
* 官网链接：[http://www.matchvs.com/](http://www.matchvs.com/) 去 Matchvs 官网注册账号，获取相关配置信息。注册游戏后，获取 `gameID` 、 `AppKey` 和 `Secret`。
* 官网教程链接: [http://www.matchvs.com/service?page=guideEgret](http://www.matchvs.com/service?page=guideEgret)
* `libsrc`为标准第三方库
* 使用 Matchvs 一定要引入白鹭引擎的 `socket` 库，因为它要通过 `websocket` 来通讯。
